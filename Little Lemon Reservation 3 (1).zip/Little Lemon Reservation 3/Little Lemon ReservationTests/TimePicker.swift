//
//  TimePicker.swift
//  Little Lemon ReservationTests
//
//  Created by Amir Aynetchi on 31/03/2023.
//

import SwiftUI

struct TimePicker: View {
    //var selectedTime: String = ""
    //let date = Date()
    var body: some View {
        
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
    
}

struct TimePicker_Previews: PreviewProvider {
    static var previews: some View {
        TimePicker()
    }
}
