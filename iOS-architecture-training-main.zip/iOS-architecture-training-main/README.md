### これは何

- iOS アプリのアーキテクチャーの勉強用のリポジトリです
- [「iOS アプリ設計パターン」](https://peaks.cc/books/iOS_architecture) を参照しながら、下記のアーキテクチャーを実装します
  - Original MVC
  - Cocoa MVC,
  - MVP
  - MVVM
  - Flux
  - VIPER
  - TCA

### まとめ記事

- 2021/09/21 - 2021/10/01 で実装を完了しました
- まとめ記事を書きました →[iOS アプリの設計を勉強しました](https://zenn.dev/st43/articles/429afeafa59914)
