//
//  LittleLemonApp.swift
//  LittleLemon
//
//  Created by kuehar on 2023/05/01.
//

import SwiftUI

@main
struct LittleLemonApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
